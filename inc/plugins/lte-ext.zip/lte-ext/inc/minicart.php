<?php

add_action( 'wp_ajax_lte_wc_cart_update', 'lte_get_the_minicart_ajax', 0 );
add_action( 'wp_ajax_nopriv_lte_wc_cart_update', 'lte_get_the_minicart_ajax', 0 );

if ( !function_exists('lte_get_the_minicart_ajax') ) {

	function lte_get_the_minicart_ajax() {

		check_ajax_referer('lte_mini_cart');
		
		echo lte_get_the_minicart();

		die();
	}
}

if ( !function_exists('lte_get_the_minicart') ) {

	function lte_get_the_minicart() {

		$out = [];
		
		if ( !function_exists( 'WC' ) ) {

			return false;
		}

		if ( empty( WC()->cart ) ) {

//			WC()->cart = new WC_Cart();
			return false;
		}


		if ( !empty(WC()->cart->get_cart()) ) {

			foreach ( WC()->cart->get_cart() as $key => $item ) {

				$product = $item['data'];

				$product_item = new WC_Product( $product->get_id() );
				$price = $product_item->get_price_html();

				$out[] = '<div class="lte-item">';

					$out[] = '<div class="lte-photo">';
						$out[] = '<span class="lte-remove" data-product_id="'.esc_attr($product->get_id()).'" data-cart_item_key="'.esc_attr($key).'"></span>';

						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ) );
						if ( !empty($image) ) $out[] = '<a href="'.esc_url(get_permalink($product->get_id())).'" class="lte-photo"><img src="'.esc_url($image[0]).'" alt="'.esc_attr($product->get_name()).'"></span>';
					$out[] = '</div>';

					$qty = $item['quantity'];
					$subtotal = $item['line_subtotal']; 
					$item_price = $item['line_subtotal'] / $item['quantity'];


					$out[] = '<div class="lte-product">';
						$out[] = '<a href="'.esc_url(get_permalink($product->get_id())).'" class="lte-name">'.esc_html($product->get_name()).'</a>';
						$out[] = '<span class="lte-price">'.esc_html($item['quantity']).'<span class="lte-x">×</span>'.$price.'</span>';
					$out[] = '</div>';

				$out[] = '</div>';
			}

			$out[] = '<div class="lte-total">';
				$out[] = '<span class="lte-total-header">'.esc_html__( 'Total:', 'lte-ext' ).'</span> <span class="lte-total-value">'.WC()->cart->get_total().'</span>';

				if (function_exists('wc_get_cart_url')) {

					$out[] = lte_button_sc([
							'header' 	=> esc_html__( 'View cart', 'lte-ext' ),
							'href' 		=> wc_get_cart_url(),
							'color' 	=> 'black',
							'hover' 	=> 'main',
/*							'size'		=> 'xs',*/
						]);
				}
			$out[] = '</div>';
		}
			else {

			$out[] = '<p class="lte-cart-warning">'.esc_html__( 'Your cart is currently empty.', 'lte-ext' ).'</p>';
		}

		return implode($out);
	}
}



