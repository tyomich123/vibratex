<?php

/**
 * LearnPress Hooks
 */

if ( function_exists('learn_press_get_course') ) {

	add_action(
		'learn-press/before-courses-loop-item',
		LP()->template( 'course' )->callback( 'loop/course/categories' ),
		2
	);

	add_action(
		'learn-press/before-courses-loop-item',
		LP()->template( 'course' )->func( 'courses_loop_item_price' ),
		3
	);

	add_action(
		'learn-press/after-courses-loop-item',
		function() { echo '<div class="lte-cut">'.get_the_excerpt().'</div>'; },
		10
	);
	
}
