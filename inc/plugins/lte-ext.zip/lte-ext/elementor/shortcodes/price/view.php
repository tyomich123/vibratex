<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Price Shortcode
 */

if ( !empty($args['list']) ) {

//  lte-scroll-'.esc_attr($args['scroll']).'

	echo '<div class="lte-price-sc-wrapper lte-price-sc lte-filter-container lte-layout-'.esc_attr($args['layout']).'">';

		echo '<div class="lte-items">';	

			foreach ( $args['list'] as $item ) {

					$item_class = '';
					if ( !empty($item['highlight']) ) $item_class = ' highlight';

				?>
				<div class="lte-item">
		    		<?php
						if ( !empty($item['img']['id']) ) {

							echo '<img src="' . esc_url(wp_get_attachment_image_url($item['img']['id'], 'vibratex-tiny-square')) . '" class="lte-image" alt="'.esc_attr($item['header']).'">';
						}
		    		?>					
				    <div class="lte-description">
				    	<div class="lte-title">
			        		<h6 class="lte-header"><?php echo wp_kses_post($item['header']); ?></h6>
			        		<span class="lte-dots"></span>
			        		<h6 class="lte-header lte-price<?php echo esc_attr($item_class) ?>"><?php echo wp_kses_post(lte_string_parse($item['price'])); ?></h6>
			        	</div>
			        	<div class="lte-descr">
			        		<?php if ( !empty($item['subheader']) ) echo wp_kses_post($item['subheader']); ?>
			        	</div>
				    </div>
				</div>
				<?php
			}

		echo '</div>';

	echo '</div>';
}

wp_reset_postdata();

