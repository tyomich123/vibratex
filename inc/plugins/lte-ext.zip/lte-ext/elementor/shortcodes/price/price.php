<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_Price_Widget extends Widget_Base {
	
   public function __construct($data = [], $args = null) {

		parent::__construct($data, $args);

		wp_register_script('swiper', lteGetPluginUrl('assets/js/swiper.min.js'), array( 'jquery' ), '5.3.8', true );
		wp_register_script('lte-frontend', lteGetPluginUrl('assets/js/frontend.js'), array( 'jquery', 'swiper' ), LTE_PLUGIN_VER, true );
   }
   
	public function get_script_depends() {
		return [ 'lte-frontend' ];
	}


	public function get_name() {
		return 'lte-price';
	}

	public function get_title() {
		return esc_html__( 'Price', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-post-list';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

		$categories = get_categories( [ 'taxonomy' => 'lte-menu-category' ]);
		$cats = array();
		foreach ($categories as $item) {

			$cats[$item->term_id] = $item->name;
		}		

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Layout', 'lte-ext' ),
			]
		);

			$this->add_control(
				'important_note',
				[
					'type' => \Elementor\Controls_Manager::RAW_HTML,
					'raw' => esc_html__( "The content of menu can be edited in Menu menu of Dashboard.", 'lte-ext'),
				]
			);		
/*
			$this->add_control(
				'cat',
				[
					'label' => esc_html__( 'Category', 'lte-ext' ),
					'type' => Controls_Manager::SELECT2,
					'multiple'	=>	true,
					'label_block' => true,
					'default' => '',
					'options' => $cats,
				]
			);			
*/
			$this->add_control(
				'layout',
				[
					'label' => esc_html__( 'Layout', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'two-cols',
					'options' => [

						'two-cols'	=>	esc_html__( "Two Columns", 'lte-ext'),
						'one-col'	=>	esc_html__( "One Column", 'lte-ext'),
					],
				]
			);	
/*
			$this->add_control(
				'scroll',
				[
					'label' => esc_html__( 'Scroll Bar', 'lte-ext' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'no',
				]
			);
*/			
/*
			$this->add_control(
				'limit',
				[
					'label' => esc_html__( 'Limit', 'lte-ext' ),
					'type' => Controls_Manager::TEXT,
					'default' => '8',
				]
			);
*/
			$repeater = new \Elementor\Repeater();

				$repeater->add_control(
					'header', [
						'label' => esc_html__( 'Header', 'lte-ext' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'label_block' => true,
					]
				);

				$repeater->add_control(
					'subheader', [
						'label' => esc_html__( 'Subheader', 'lte-ext' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'label_block' => true,
					]
				);

				$repeater->add_control(
					'price', [
						'label' => esc_html__( 'Price', 'lte-ext' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'label_block' => true,
					]
				);

				$repeater->add_control(
					'href',
					[
						'label' => __( 'Href', 'lte-ext' ),
						'type' => \Elementor\Controls_Manager::URL,
						'label_block' => true,
						'description' => esc_html__( "Optional", 'lte-ext'),
					]
				);	

				$repeater->add_control(
					'img',
					[
						'label' => esc_html__( 'Image', 'lte-ext' ),
						'type' => \Elementor\Controls_Manager::MEDIA,
						'label_block' => true,
					]							
				);

				$repeater->add_control(
					'highlight',
					[
						'label' => __( 'Highlight', 'lte-ext' ),
						'type' => \Elementor\Controls_Manager::SWITCHER,
					]
				);	

			$this->add_control(
				'list',
				[
					'label' => __( 'Items', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'title_field' => '{{{ header }}}',
				]
			);	

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		lte_sc_output('price', $settings);
	}
}




