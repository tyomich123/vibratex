<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Zoom Slider Shortcode
 */

$query_args = array(
	'post_type' => 'sliders',
	'post_status' => 'publish',
	'posts_per_page' => 0,	
	'orderby' => 'date',
);

if ( !empty($args['cat']) ) {

	$query_args['tax_query'] = 	array(
		array(
            'taxonomy'  => 'sliders-category',
            'field'     => 'if', 
            'terms'     => array(esc_attr($args['cat'])),
		)
    );
}

if ( $args['type'] == 'swiper' ) {

	$query = new WP_Query( $query_args );
	if ( $query->have_posts() ) {

		$args['swiper_effect'] = 'fade';
		$args['swiper_arrows'] = 'false';

		if ( $args['arrows'] == 'default') $args['swiper_arrows'] = 'sides';
		if ( $args['bullets'] == 'default') $args['swiper_pagination'] = 'bullets';
		$args['swiper_autoplay'] = $args['interval'];

		echo lte_swiper_get_the_container('lte-slider-swiper', $args);

			echo '<div class="swiper-wrapper">';

			$x = 0;

			while ( $query->have_posts() ) {

				$x++;

				$query->the_post();		

				echo '<div class="swiper-slide">';

					if (class_exists("\\Elementor\\Plugin")) {

			            $pluginElementor = \Elementor\Plugin::instance();
			            //$out = $pluginElementor->frontend->get_builder_content(get_the_ID(), true);
//			            echo preg_replace('~<style(.*?)</style>~Usi', "", $out);

			        	if ( isset( $_GET['action'] ) || isset($_GET['elementor-preview']) ) {

				            $contentElementor = \Elementor\Plugin::instance()->frontend->get_builder_content(get_the_ID(), true);
		//					$contentElementor = preg_replace('~<style(.*?)</style>~Usi', "", $contentElementor);
			            }
			            	else {

				       		
				            $contentElementor = \Elementor\Plugin::instance()->frontend->get_builder_content(get_the_ID(), false);
				       	}

				       	echo $contentElementor;
			        }

				echo '</div>';
			}

			echo '</div>';
		
		echo '</div>
		</div>';

		wp_reset_postdata();
	}

}
	else
if ( $args['type'] == 'zs' ) {

	$class[] = ' zoom-'. esc_attr($args['zoom']);
	$class[] = ' zoom-origin-'. esc_attr($args['zs-origin']);
	$class[] = ' lte-zs-overlay-'. esc_attr($args['overlay']);

	if ($args['zoom'] == 'out' OR $args['zoom'] == 'fade') {

		$init_zoom = '1.0';
	}
		else {

		$init_zoom = '1.2';
	}


	$query = new WP_Query( $query_args );
	if ( $query->have_posts() ) {

		$json_next = $json_all = $json = array();
		$html = array();
		$key = 0;

		$lte_custom_css = '';

		while ( $query->have_posts() ) {

			$query->the_post();	

			$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'vibratex-client' );

			$json_all[] = [

				'title'	=>	fw_get_db_post_option(get_The_ID(), 'header-alt'),
				'image'	=>	$image[0],
			];
		}

		$key = -1;
		while ( $query->have_posts() ) {

			$key++;
			$query->the_post();		

			$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );
			if ( !empty($image) ) {

				$json[] = $image[0];
			}
				else {

				$json[] = '';
			}

			if ( !empty($json_all[$key + 1]) ) {

				$json_next[] = $json_all[$key + 1];
			}
				else {

				$json_next[] = $json_all[0];
			}
				
			$mobile_bg = fw_get_db_post_option(get_The_ID(), 'mobile_bg');


			if ( !empty($mobile_bg) ) {

				$json_mobile[] = $mobile_bg['url'];
			}
				else {

				$json_mobile[] = '';
			}			

	        if (class_exists("\\Elementor\\Plugin")) {

	        	if ( isset( $_GET['action'] ) || isset($_GET['elementor-preview']) ) {

		            $contentElementor = \Elementor\Plugin::instance()->frontend->get_builder_content(get_the_ID(), true);
//					$contentElementor = preg_replace('~<style(.*?)</style>~Usi', "", $contentElementor);
	            }
	            	else {

		       		
		            $contentElementor = \Elementor\Plugin::instance()->frontend->get_builder_content(get_the_ID(), false);
		       	}

				$html[] = $contentElementor;
	        }
		}

		if ( $args['nav'] === 'true' ) $json_next = json_encode( $json_next );

		$json = json_encode( $json );

		$args['arrow_left'] = '';
		$args['arrow_right'] = '';

		if ( !empty($args['arrows']) AND $args['arrows'] === 'default' ) {
		
			$args['arrows'] = 'true';
		}
			else
		if ( !empty($args['arrows']) AND $args['arrows'] === 'only-right' ) {
		
			$args['arrows'] = 'right';
			$class[] = 'arrow-only-right';
		}

		if ( !empty($args['bullets']) AND $args['bullets'] === 'default' ) {
		
			$args['bullets'] = 'true';
			$class[] = 'bullets-right';
		}
			else
		if ( !empty($args['bullets']) AND $args['bullets'] === 'bottom' ) {
		
			$args['bullets'] = 'true';
			$class[] = 'bullets-bottom';
		}
			else				
		if ( !empty($args['bullets']) AND $args['bullets'] === 'outside' ) {
		
			$args['bullets'] = 'outside';
			$class[] = 'bullets-outside';
		}

		echo '<div class="lte-slider-zoom '. esc_attr( implode(' ', $class) ) .'" data-zs-prev="'. esc_attr( $args['arrow_left'] ) .'" data-zs-next="'. esc_attr( $args['arrow_right'] ) .'" data-zs-overlay="'. esc_attr( $args['overlay'] ) .'" data-zs-initzoom="'. esc_attr( $init_zoom ) .'" data-zs-speed="'. esc_attr($args['zs-speed']) .'" data-zs-interval="'. esc_attr($args['zs-interval']) .'" data-zs-switchSpeed="'. esc_attr($args['zs-switch']) .'" data-zs-arrows="'.esc_attr($args['arrows']).'" data-zs-bullets="'.esc_attr($args['bullets']).'" data-zs-titles=\''. filter_var( ($json_next), FILTER_SANITIZE_SPECIAL_CHARS ) .'\' data-zs-src=\''. filter_var( $json, FILTER_SANITIZE_SPECIAL_CHARS ) .'\' data-zs-src2=\''. filter_var( json_encode($json_mobile), FILTER_SANITIZE_SPECIAL_CHARS ) .'\'>';

			if ( !empty($args['tagline']) AND $args['tagline'] === 'default' ) {
			
				echo do_shortcode('[lte-header-tagline]');
			}

			if ( !empty($args['overlay-lines']) AND $args['overlay-lines'] === 'vertical-lines' ) {

				echo '<div class="lte-overlay-lines lte-background-overlay"></div>';
			}

			if ( !empty($args['social']) AND $args['social'] === 'outside' ) {

				echo do_shortcode('[lte-social type="titles"]');
			}

			echo '<div class="container lte-zs-slider-wrapper lte-slides-count-'.esc_attr(sizeof($html)).'">';
				
				foreach ( $html as $key => $item_escaped ) {

					if ( $key == 0 ) $class = ' inited visible '; else $class = '';
					if ( sizeof($html) == 1 ) $class .= ' single';
					echo '<div class="lte-zs-slider-inner '.$class.' lte-zs-slide-'.esc_attr($key).'" data-index="'.esc_attr($key).'" style="opacity: 0;">';
						echo $item_escaped;
					echo '</div>';				
				}


				if ( !empty($args['social']) AND $args['social'] === 'true' ) {

					echo do_shortcode('[lte-social type="titles"]');
				}

			echo '</div>';

		echo '</div>';
		
	}
}

wp_reset_postdata();

