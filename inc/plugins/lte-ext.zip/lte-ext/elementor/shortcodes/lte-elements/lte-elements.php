<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;

class LTE_Lte_Elements_Widget extends Widget_Base {

	public function get_name() {
		return 'lte-elements';
	}	

	public function get_title() {
		return esc_html__( 'Lte-Elements Widget', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-headphones';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'LTE-Elements', 'lte-ext' ),
			]
		);	

		$this->add_control(
			'element_type', 
			[
				'label' => esc_html__( 'Element Type', 'lte-ext' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'logo',
				'options' => [
					'logo'	=>	esc_html__( 'Your Logo', 'lte-ext' ),
					'social_icons'	=>	esc_html__( 'Your Social Icons', 'lte-ext' ),
				],
			]
		);

		$this->add_control(
			'logo_type',
			[
				'label' => esc_html__( 'Logo Type', 'lte-ext' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'black',
				'options' => [
					'black'	=>	esc_html__( 'Logo Black', 'lte-ext' ),
					'white'	=>	esc_html__( 'Logo White', 'lte-ext' ),
				],
				'condition' => ['element_type' => ['logo', 'logo'] ],
			]
		);

		$this->add_control(
			'inline',
			[
				'label' => esc_html__( 'Inline', 'lte-ext' ),
				'type' => Controls_Manager::SWITCHER,
				'prefix_class' => 'lte-media-inline-',
				'condition' => ['element_type' => ['logo', 'logo'] ],
			]
		);	
			
		$this->add_responsive_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
				'condition' => ['element_type' => ['logo'] ],
			]
		);

		$this->add_control(
			'text_before',
			[
				'label' => esc_html__( 'Text before icons', 'lte-ext' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( "Follow us:", 'lte-ext'),
				'label_block'	=>	true,
				'condition' => [
					'element_type' => ['social_icons'],
				],						
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		lte_sc_output('lte-elements', $settings);
	}
}




