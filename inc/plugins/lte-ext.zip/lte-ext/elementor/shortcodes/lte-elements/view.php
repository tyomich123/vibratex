<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Lte-elements 
 */

if ( $args['element_type'] == 'logo' ) {
  echo do_shortcode('[lte-logo color='. esc_attr($args['logo_type']) .']');  
}

if ( $args['element_type'] == 'social_icons' ) {
  echo do_shortcode('[lte-social text-before="'. esc_attr($args['text_before']) .'"]');  
}
