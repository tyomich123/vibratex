<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Gallery Shortcode
 */

$list = fw_get_db_post_option( $args['album'], 'photos' );
if ( !empty($list) ) {

	$item_class = [];
	$item_class[] = 'swipebox lte-gallery';

	if ( $args['layout'] == 'slider' ) {

		$args['swiper_breakpoint_xl'] = $args['columns_xl'];
		$args['swiper_breakpoint_lg'] = $args['columns_lg'];
		$args['swiper_breakpoint_md'] = $args['columns_md'];
		$args['swiper_breakpoint_sm'] = $args['columns_sm'];
		$args['swiper_breakpoint_ms'] = $args['columns_ms'];
		$args['swiper_breakpoint_xs'] = $args['columns_xs'];
		$args['swiper_slides_per_group'] = -1;
		$args['swiper_arrows'] = $args['swiper_arrows'];
		$args['swiper_pagination'] = 'false';
		$args['space_between'] = "30";
		$args['swiper_autoplay'] = $args['autoplay'];
		$args['swiper_speed'] = 1500;
		$args['swiper_loop'] = true;


		$item_class[] = 'swiper-slide';
		echo lte_swiper_get_the_container('lte-gallery-sc lte-gallery-slider swipebox-gallery', $args);
		echo '<div class="swiper-wrapper">';
	}
		else {


		$item_class = array_merge($item_class, lte_responsive_cols($args));

/*
		if ( !empty($_GET['action']) AND $_GET['action'] == 'elementor' ) {

			$args['limit'] = 6;
		}

		if ( $args['layout'] == 'grid' ) {

			echo '<div class="lte-gallery-sc lte-gallery-grid-layout swipebox-gallery">';
		}
			else {
*/
			echo '<div class="lte-gallery-sc swipebox-gallery lte-gallery-grid"><div class="row">';
//		}
	}
/*
	if ( $args['layout'] == 'grid' ) {

		$x = 0;
		foreach ( $list as $item ) {

			$x++;

			echo '<div class="i-'.esc_attr($x).'" style="background-image: url('. wp_get_attachment_image_url( $item['attachment_id'], 'full' ) .')">';

				echo '<a href="'.esc_url( $item['url'] ).'" class="'.esc_attr(implode(' ', $item_class)).'">';
				echo '</a>';

			echo '</div>';


			if ( !empty($args['limit']) AND $args['limit'] == $x ) {

				break;
			}
		}
	}
		else {
*/
		$x = 0;
		foreach ( $list as $item ) {

			$x++;
			
			echo '<a href="'.esc_url( $item['url'] ).'" class="'.esc_attr(implode(' ', $item_class)).'">';
				echo '<span>' . wp_get_attachment_image( $item['attachment_id'], 'vibratex-gallery-big' ) . '</span>' ;
			echo '</a>';

			if ( !empty($args['limit']) AND $args['limit'] == $x ) {

				break;
			}
		}
//	}


	if ( !empty($args['layout'] == 'slider') ) {

		echo '</div>';	
	}		

	echo '</div></div>';
}

