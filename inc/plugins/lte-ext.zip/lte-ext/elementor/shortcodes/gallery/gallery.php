<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_Gallery_Widget extends Widget_Base {

	public function __construct($data = [], $args = null) {

		parent::__construct($data, $args);

		wp_enqueue_script('swiper');
		wp_enqueue_script('lte-frontend');
	}

	public function get_script_depends() {
		return [ 'lte-frontend' ];
	}
	
	public function get_name() {
		return 'lte-gallery';
	}

	public function get_title() {
		return esc_html__( 'Gallery', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

		$albums = lteGetGalleryPosts();

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Layout', 'lte-ext' ),
			]
		);

			$this->add_control(
				'important_note',
				[
					'type' => \Elementor\Controls_Manager::RAW_HTML,
					'raw' => esc_html__( "The content of galleries can be edited in Gallery menu of Dashboard.", 'lte-ext'),
				]
			);		

			$this->add_control(
				'layout',
				[
					'label' => esc_html__( 'Layout', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'static',
					'options' => [

						'slider'	=>	esc_html__( "Slider", 'lte-ext'),
						'static'	=>	esc_html__( "Static", 'lte-ext'),
//						'grid'		=>	esc_html__( "Static Grid", 'lte-ext'),
					],
				]
			);	

			$this->add_control(
				'album',
				[
					'label' => esc_html__( 'Album', 'lte-ext' ),
					'type' => Controls_Manager::SELECT2,
					'label_block' => true,
					'default' => '',
					'options' => $albums,
				]
			);	

			$this->add_control(
				'limit',
				[
					'label' => esc_html__( 'Limit', 'lte-ext' ),
					'type' => Controls_Manager::TEXT,
					'default' => '6',
				]
			);

			$this->add_control(
				'links',
				[
					'label' => esc_html__( 'Lightbox Links', 'lte-ext' ),
					'type' => Controls_Manager::SWITCHER,
					'default' => 'yes',
				]
			);

			$this->add_control(
				'swiper_arrows',
				[
					'label' => esc_html__( 'Arrows', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'disabled',
					'options' => [
						'false' => esc_html__( 'Disabled', 'lte-ext' ),
						'right-top' => esc_html__( 'Right Top', 'lte-ext' ),
						'sides-outside' => esc_html__( 'Sides', 'lte-ext' ),
						'bottom' => esc_html__( 'Bottom', 'lte-ext' ),
					],
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label' => esc_html__( 'Autoplay, ms', 'lte-ext' ),
					'type' => Controls_Manager::TEXT,
					'default' => '1000',
					'condition' => [
						'layout' => ['slider'],
					],					
					
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_cols',
			[
				'label' => esc_html__( 'Responsive Columns', 'lte-ext' ),
			]
		);

			$this->add_control(
				'important_columns',
				[
					'type' => \Elementor\Controls_Manager::RAW_HTML,
					'raw' => esc_html__( "Please consider some column settings could not work correctly with shortcode.", 'lte-ext'),
				]
			);		

			foreach ( lte_elementor_responsive_options([ 1 => 1, 2, 3, 4, 5, 6, 12 ]) as $key => $val ) {

				$val['type'] = Controls_Manager::SELECT;
				$this->add_control( $key, $val );
			}

		$this->end_controls_section();		
	
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		lte_sc_output('gallery', $settings);
	}
}




