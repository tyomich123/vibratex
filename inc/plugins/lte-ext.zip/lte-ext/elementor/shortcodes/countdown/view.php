<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Countdown Shortcode
 */

echo '
	<div class="lte-countdown" data-date="'.esc_attr($args['date']).'" data-template="'.esc_attr(($args['template'])).'"></div>
';

