<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_Countdown_Widget extends Widget_Base {

	public function get_name() {
		return 'lte-countup';
	}

	public function get_title() {
		return esc_html__( 'Countdown', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-countdown';
	}
/*
	public function get_script_depends() {
		return [ 'jquery-numerator' ];
	}
*/
	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

		// Template can be edited in VC and doesn't need to be translated
		$template = '<span>%D <span>days</span></span>
<span class="divider">:</span>						
<span>%H <span>hours</span></span>
<span class="divider">:</span>
<span>%M <span>minutes</span></span>
<span class="divider">:</span>
<span>%S <span>seconds</span></span>';


		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Layout', 'lte-ext' ),
			]
		);

		$this->add_control(
			'date',
			[
				'label' => esc_html__( 'Date', 'lte-ext' ),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
				'label_block' => true,
			]
		);		

		$this->add_control(
			'template',
			[
				'label' => esc_html__( 'Template', 'lte-ext' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default'	=>	$template,
				"description"	=>	'Check the https://www.php.net/manual/en/datetime.format.php for date format variables',			
			]
		);		

		$this->end_controls_section();
	}

	protected function render() {

		wp_enqueue_script( 'lte-countdown', lteGetPluginUrl('/elementor/shortcodes/countdown/countdown.js'), array('jquery'), null, true );
		wp_enqueue_script( 'countdown', lteGetPluginUrl('/elementor/shortcodes/countdown/jquery.countdown.js'), array('jquery'), null, true );

		$settings = $this->get_settings_for_display();

		lte_sc_output('countdown', $settings);
	}
}




