<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Blogs Shortcode
 */

$query_args = array(
	'post_type' => 'post',
	'post_status' => 'publish',
	'posts_per_page' => $args['limit'],
);

if ( !empty($args['ids']) ) $query_args['post__in'] = explode(',', esc_attr($args['ids']));
	else
if ( !empty($args['cat']) ) $query_args['category__in'] = $args['cat'];

if ( !empty($args['orderby']) ) {

	$query_args['orderby'] = $args['orderby'];
}		

if ( !empty($args['orderway']) ) {

	$query_args['order'] = $args['orderway'];
}

if ( !empty($args['featured_img_only']) ) {

	$query_args['meta_key'] = '_thumbnail_id';
}

$query = new WP_Query( $query_args );

if ( $query->have_posts() ) {

	set_query_var( 'lte_display_excerpt', false );
	if ( !empty($args['excerpt_display']) ) {

		set_query_var( 'lte_display_excerpt', true );
	}

	set_query_var( 'lte_sc_excerpt_size', false );
	if ( !empty( $args['excerpt'] ) ) {

		set_query_var( 'lte_sc_excerpt_size', $args['excerpt'] );
	}	

	$cols = '';
/*	
	if ( $args['columns'] == 1) {

		$cols = 'col-xs-12';
	}
		else
	if ( $args['columns'] == 2) {

		$cols = 'col-lg-6 col-md-12 col-sm-12 col-ms-12 col-xs-12';
	}
		else
	if ( $args['columns'] == 3) {

		$cols = 'col-lg-4 col-md-4 col-sm-6 col-ms-12 col-xs-12';
	}
		else
	if ( $args['columns'] == 4) {

		$cols = 'col-lg-3 col-md-6 col-sm-6 col-ms-12 col-xs-12';
	}
*/
	$cols = implode(' ', lte_responsive_cols($args));


	$class = array();
	$class[] = 'layout-'.$args['layout'];
	// $class[] = 'layout-cols-'.$args['columns'];

	if ( $args['cols_hide_last_odd'] == 'yes' ) {

		$class[] = 'hideLastOdd';
	}

	set_query_var( 'vibratex_layout', $args['layout'] );

	echo '<div class="blog lte-blog-sc row centered '.esc_attr(implode(' ', $class)).'">';

	$x = 0;
	while ( $query->have_posts() ) {

		$query->the_post();	
		$x++;

		if ( $args['layout'] == 'images-left' ) {

			echo get_template_part( 'tmpl/post-formats/list' );
		}
			else
		if ( in_array($args['layout'], array('featured', 'featured-rows')) ) {

			$class = '';
			if ( $x == 1 ) {

				echo '<div class="lte-featured-large col-xl-6 col-lg-6 col-md-12 col-sm-12 col-ms-12 col-xs-12">';
			}

				if ( $x <= 1  ) {
				
					echo get_template_part( 'tmpl/post-formats/list' );
				}

				if ( $x == 2 ) {

					echo '</div><div class="lte-featured-small col-xl-6 col-lg-6 col-md-12 col-sm-12 col-ms-12 col-xs-12">';
				}

				if ( $x >= 2 ) {

					echo get_template_part( 'tmpl/post-formats/list' );
				}

				if ( $x == 4 OR $x == $query->post_count ) {

					echo '</div>';
				}

				set_query_var( 'lte_display_excerpt', false );
		}
			else {

				echo '<div class="items '.esc_attr($cols).'">';
//					echo get_template_part( 'tmpl/post-formats/list' );
					echo get_template_part( 'tmpl/post-formats/list', get_post_format() );
				echo '</div>';
		}

	}

	echo '</div>';
	echo '<div class="clearfix"></div>';

	wp_reset_postdata();
	set_query_var( 'lte_display_excerpt', false );
	set_query_var( 'lte_sc_excerpt_size', false );
}

