<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_History_Widget extends Widget_Base {

   public function __construct($data = [], $args = null) {

		parent::__construct($data, $args);

//		wp_register_script('lte-history', lteGetPluginUrl('/elementor/shortcodes/history/history.js'), array( 'jquery' ), LTE_PLUGIN_VER, true );
//		wp_enqueue_script('lte-history');
   }

	public function get_name() {
		return 'lte-history';
	}

	public function get_title() {
		return esc_html__( 'History', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-banner';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Layout', 'lte-ext' ),
			]
		);

		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Logo', 'lte-ext' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
			]
		);


		$repeater = new \Elementor\Repeater();
			
			$repeater->add_control(
				'year', [
					'label' => esc_html__( 'Year', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'label_block' => true,
				]
			);

			$repeater->add_control(
				'header', [
					'label' => esc_html__( 'Header', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'label_block' => true,
				]
			);

			$repeater->add_control(
				'text',
				[
					'label' => esc_html__( 'Text', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'label_block' => true,
				]
			);

			$repeater->add_control(
				'image',
				[
					'label' => esc_html__( 'Logo', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'label_block' => true,
				]
			);

		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Items', 'lte-ext' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ header }}}',
			]
		);


		$this->end_controls_section();
	}

	protected function render() {


		$settings = $this->get_settings_for_display();
		lte_sc_output('history', $settings);
	}
}




