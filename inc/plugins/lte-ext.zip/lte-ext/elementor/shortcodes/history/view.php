<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * History Shortcode
 */

echo '<div class="lte-history-sc">';

	echo '<div class="container">';

		echo '<div class="lte-item-row lte-row-1">';

			foreach ( $args['list'] as $k => $item ) {

				if ( empty( $item['header'] ) ) {

					$item['header'] = '.';
				}

				echo '<div class="lte-item">';

					if ( !empty($item['header']) ) {

						echo '<div class="lte-item-descr">';

							echo '<h6 class="lte-year">'.esc_html($item['year']).'</h6>';
							echo '<h5 class="lte-header">'.esc_html($item['header']).'</h5>';
							echo '<p>'.wp_kses_post($item['text']).'</p>';

						echo '</div>';



						$img = wp_get_attachment_image_src($item['image']['id'], 'vibratex-product-tiny');

						if ( empty($img) ) {

							$image = $args['image']['url'];
						}
							else {

							$image = $img[0];
						}

						if ( !empty($args['image']['url']) )echo '<div class="lte-item-logo"><img src="' . esc_url($image) . '" alt="'.esc_attr($item['header']).'"></div>';
					}

				echo '</div>';
			}

		echo '</div>';

	echo '</div>';

echo '</div>';

echo '<div class="lte-history-sc">';
	echo '<div class="lte-line"></div>';
echo '</div>';


echo '<div class="lte-history-sc">';

	echo '<div class="container">';

		echo '<div class="lte-item-row lte-row-2">';

		//	echo '<div class="lte-item-dot"></div>';
		//	echo '<div class="lte-item-line"></div>';	

			foreach ( $args['list'] as $k => $item ) {

				if ( empty( $item['header'] ) ) {

					$item['header'] = '.';
				}

				echo '<div class="lte-item">';

					if ( !empty($item['header']) ) {

						echo '<div class="lte-item-descr">';

							echo '<h6 class="lte-year">'.esc_html($item['year']).'</h6>';
							echo '<h5 class="lte-header">'.esc_html($item['header']).'</h5>';
							echo '<p>'.wp_kses_post($item['text']).'</p>';

						echo '</div>';

						echo '<div class="lte-item-dot"></div>';
						echo '<div class="lte-item-line"></div>';

						$img = wp_get_attachment_image_src($item['image']['id'], 'vibratex-product-tiny');

						if ( empty($img) ) {

							$image = $args['image']['url'];
						}
							else {

							$image = $img[0];
						}

						if ( !empty($args['image']['url']) )echo '<div class="lte-item-logo"><img src="' . esc_url($image) . '"  alt="'.esc_attr($item['header']).'"></div>';
					}

				echo '</div>';
			}	

		echo '</div>';

	echo '</div>';

echo '</div>';

