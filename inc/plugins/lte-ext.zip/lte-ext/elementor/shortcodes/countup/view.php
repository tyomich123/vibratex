<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * CountUp Shortcode
 */

$class = [];
$class[] = 'lte-layout-'.$args['layout'];
$class[] = 'lte-style-'.$args['style'];

echo '<div class="lte-countup '.esc_attr(implode(' ', $class)).'">';
	echo '<div class="row">';

		$div_class = '';
		if ( sizeof($args['list']) == 6 ) $div_class = ' col-md-2 ';
			else
		if ( sizeof($args['list']) == 4 ) $div_class = ' col-lg-3 col-md-6 col-sm-6 col-ms-12 col-xs-12 ';
			else
		if ( sizeof($args['list']) == 3 ) $div_class = ' col-md-4 col-sm-4 ';
			else
		if ( sizeof($args['list']) == 2 ) $div_class = ' col-md-6 col-xs-12 ';

		$div_class .= ' lte-icon-color-'.$args['icon-color'];

		$id = 'lte-countup-'.mt_rand();

		foreach ( $args['list'] as $k => $item ) {

			$item['header'] = lte_string_parse($item['header']);
			if ( !empty($item['prefix']) ) $prefix = $item['prefix']; else $prefix = '';
			if ( !empty($item['suffix']) ) $suffix = $item['suffix']; else $suffix = '';

			$item_class = '';
			if ( $args['style'] == 'default' ) {

				$item_class = 'lte-countup-animation';
			}
				else
			if ( $args['style'] == 'static' ) {

				$item_class = '';
			}
				else
			if ( $args['style'] == 'static-bg' ) {

				$div_class .= ' lte-bg-white';
			}

			echo '
				<div class="'.esc_attr($div_class).' lte-item-color-'.esc_attr($item['color']).' center-flex countUp-wrap">
					<div class=" countUp-item item">
						<div class="lte-countup-inner">';

						if ( $args['style'] == 'circle' ) {

							echo '<canvas id="lte-countup-circle-'.mt_rand(1000,9999).'-canvas" width="156" height="156"></canvas><div class="lte-chart-doughnut" data-percent="'.esc_attr($item['ending_number']).'" data-color="'.esc_attr($item['color']).'"></div>';
							
						}

						if ( !empty($item['icon']) ) {

							\Elementor\Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] );
						}

						echo '<div class="lte-countup-content">
							<h2 class="lte-header">'.
							esc_html($prefix).
							'<span class="'.esc_attr($item_class).'">'.
								esc_html($item['ending_number']).
							'</span>'.
							esc_html($suffix).
						'</h2>
						<h4 class="lte-subheader">'.wp_kses_post($item['header']).'</h4></div>
						
						<span class="lte-countup-background-text">'.
						esc_html($prefix) . esc_html($item['ending_number']). esc_html($suffix).
						'</span>
						';

					echo '
						</div>
					</div>					
				</div>';
		}


	echo '</div>';
echo '</div>';

