<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_Parallax_Slider_Widget extends Widget_Base {

   public function __construct($data = [], $args = null) {

		parent::__construct($data, $args);
/*
		wp_register_script( 'lte-parallax-slider', lteGetPluginUrl('elementor/shortcodes/parallax-slider/jquery.parallax-slider.js'), array('jquery'), null, true );
		wp_register_style( 'lte-parallax-slider', lteGetPluginUrl('elementor/shortcodes/parallax-slider/zoom-slider.css') );
*/		
   }
/*
	public function get_script_depends() {
		return [ 'lte-parallax-slider' ];
	}

	public function get_style_depends() {
		return [ 'lte-parallax-slider' ];
	}
*/
	public function get_name() {
		return 'lte-parallax-slider';
	}

	public function get_title() {
		return esc_html__( 'Parallax Slider', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-slides';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Layout', 'lte-ext' ),
			]
		);

			$this->add_control(
				'important_note',
				[
					'type' => \Elementor\Controls_Manager::RAW_HTML,
					'raw' => esc_html__( "The slider uses predefined animation and elements, which can be replaced.", 'lte-ext'),
				]
			);		

			$this->add_control(
				'header_1', [
					'label' => esc_html__( 'Header 1', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'label_block' => true,
				]
			);

			$this->add_control(
				'header_2', [
					'label' => esc_html__( 'Header 2', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'label_block' => true,
				]
			);

			$this->add_control(
				'image_sky',
				[
					'label' => esc_html__( 'Sky Background', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'label_block' => true,
				]
			);

			$this->add_control(
				'image_sea',
				[
					'label' => esc_html__( 'Sea Background', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'label_block' => true,
				]
			);

			$this->add_control(
				'image_leaf-1',
				[
					'label' => esc_html__( 'Leaf 1 Background', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'label_block' => true,
				]
			);

			$this->add_control(
				'image_leaf-2',
				[
					'label' => esc_html__( 'Leaf 2 Background', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'label_block' => true,
				]
			);

			$this->add_control(
				'image_yoga',
				[
					'label' => esc_html__( 'Yoga Background', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'label_block' => true,
				]
			);

			$this->add_control(
				'image_podium',
				[
					'label' => esc_html__( 'Podium Background', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'label_block' => true,
				]
			);
			
		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		lte_sc_output('parallax-slider', $settings);
	}
}




