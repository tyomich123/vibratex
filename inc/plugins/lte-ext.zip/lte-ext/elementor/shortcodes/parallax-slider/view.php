<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Parallax Slider Shortcode
 */

echo '<div class="lte-parallax-slider-sc">';
	
	echo '<div id="lte-parallax-slider-sc-wrap">';

		if ( !empty($args['header_1'])) {

			echo '<h2 class="lte-header-1" id="lte-pheader-1" data-depth-x="0.25">'.esc_html($args['header_1']).'</h2>';
		}

		if ( !empty($args['header_2'])) {

			echo '<h2 class="lte-header-2" id="lte-pheader-2" data-depth-x="-0.25">'.esc_html($args['header_2']).'</h2>';
		}

	echo '</div>';

	if ( !empty($args['image_sky']['url'])) {

		echo '<div class="lte-parallax-sky" data-paroller-factor="-0.5" data-paroller-offset="400" data-paroller-type="foreground" style="background-image: url('.esc_url($args['image_sky']['url']).');"></div>';
	}

	if ( !empty($args['image_sea']['url'])) {

		echo '<div class="lte-parallax-sea" data-paroller-factor="-0.3" data-paroller-type="foreground" style="background-image: url('.esc_url($args['image_sea']['url']).');"></div>';
	}

	if ( !empty($args['image_leaf-1']['url'])) {

		echo '<div class="lte-parallax-leaf-1" data-paroller-factor="0.3" data-paroller-offset="0"  data-paroller-type="foreground" style="background-image: url('.esc_url($args['image_leaf-1']['url']).');"></div>';
	}

	if ( !empty($args['image_leaf-2']['url'])) {

		echo '<div class="lte-parallax-leaf-2" data-paroller-factor="0.3"  data-paroller-offset="0" data-paroller-type="foreground" style="background-image: url('.esc_url($args['image_leaf-2']['url']).');"></div>';
	}

	if ( !empty($args['image_yoga']['url'])) {

		echo '<div class="lte-parallax-yoga"style="background-image: url('.esc_url($args['image_yoga']['url']).');"></div>';
	}

	if ( !empty($args['image_podium']['url'])) {

		echo '<div class="lte-parallax-podium"  style="background-image: url('.esc_url($args['image_podium']['url']).');"></div>';
	}

echo '</div>';



