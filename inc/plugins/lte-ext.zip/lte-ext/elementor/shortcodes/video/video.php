<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_Video_Widget extends Widget_Base {

	public function get_name() {
		return 'lte-video';
	}

	public function get_title() {
		return esc_html__( 'Video Popup', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-youtube';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Layout', 'lte-ext' ),
			]
		);

			$this->add_control(
				'href',
				[
					'label' => __( 'Href', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::URL,
					'description' => esc_html__( 'Full Youtube/Vimeo link including https://www.youtube.com/', 'lte-ext' ),
					'label_block' => true,
				]
			);


			$this->add_control(
				'style',
				[
					'label' => esc_html__( 'Style', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'solid',
					'options' => [
//						'plain' 	=> esc_html__('Plain', 'lte-ext'),
//						'bg' 		=> esc_html__('With Background', 'lte-ext'),
						'solid'		=> esc_html__('Icon Only', 'lte-ext'),

						'icon'		=> esc_html__('Icon with Text Right', 'lte-ext'),
/*
						'icon-top'	=> esc_html__('Icon with Text Top', 'lte-ext'),
*/						
					],
				]
			);			

			$this->add_control(
				'image',
				[
					'label' => esc_html__( 'Background', 'lte-ext' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'label_block' => true,
					'condition' => ['style' => ['bg'] ],
				]
			);

			$this->add_control(
				'header',
				[
					'label' => esc_html__( 'Header', 'lte-ext' ),
					'type' => Controls_Manager::TEXT,
					'label_block'	=>	true,
					'condition' => ['style' => ['bg', 'icon', 'icon-top'] ],
				]
			);
/*
			$this->add_control(
				'color',
				[
					'label' => esc_html__( 'Icon Color', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'default',
					'options' => [
						'default'	=> esc_html__('Default', 'lte-ext'),
						'black'		=> esc_html__('Black', 'lte-ext'),
						'main'		=> esc_html__('Main Color', 'lte-ext'),
						'second'	=> esc_html__('Second Color', 'lte-ext'),
						'white'		=> esc_html__('White', 'lte-ext'),
					],
				]
			);	
*/
			
		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		lte_sc_output('video', $settings);
	}
}




