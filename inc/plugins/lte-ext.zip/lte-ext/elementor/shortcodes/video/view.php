<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Video Popup Shortcode
 */


$style_escaped = '';
if ( $args['style'] == 'bg' AND !empty($args['image']) ) {

	$style_escaped = ' style="background-image: url('.esc_url($args['image']['url']).')"';
}

echo '<a href="'. esc_url($args['href']['url']) .'" class="lte-video-popup lte-style-'.esc_attr($args['style']).'  swipebox" '.$style_escaped.'>';
		echo '<span><span></span></span>';

		if ( !empty($args['header']) ) {

			echo '<h6 class="lte-header">'.wp_kses_post(lte_string_parse($args['header'])).'</h6>';
		}

echo '</a>';


