<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Hover Links Shortcode
 */

echo '<div class="lte-hover-links lte-cursor-follow-parent">';
	$target = '';
	if ( $args['target'] == 'blank') {

		$target = ' target="_blank" ';
	}

	foreach ( $args['list'] as $k => $item ) {

		$img = wp_get_attachment_image_src($item['image']['id'], 'vibratex-team-square');

		echo '<a href="'.esc_url($item['href']['url']).'" class="lte-item">
			<span>'.esc_html($item['header']).'</span>';
			echo '<img src="' . esc_url($img[0]) . '" class="lte-tab-cursor" alt="'.esc_attr($item['header']).'">';
		echo '</a>';
	}
echo '</div>';

