<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Services Shortcode
 */

$query_args = array(
	'post_type' => 'services',
	'post_status' => 'publish',
	'posts_per_page' => (int)($args['limit']),
);

if ( !empty($args['cat']) ) {

	$query_args['tax_query'] = 	array(
		array(
            'taxonomy'  => 'services-category',
            'field'     => 'if', 
            'terms'     => array(esc_attr($args['cat'])),
		)
    );
}

if ( !empty($args['orderby']) ) {

	$query_args['orderby'] = $args['orderby'];
}

if ( !empty($args['orderway']) ) {

	$query_args['order'] = $args['orderway'];
}

$query = new WP_Query( $query_args );
if ( $query->have_posts() ) {

	$item_class = [];
	$swiper_item_class = '';
	if ( !empty($args['swiper']) OR $args['layout'] == 'slider' ) {

		$atts['swiper_pagination'] = 'fraction';
		$swiper_item_class = 'swiper-slide';
		echo lte_vc_swiper_get_the_container('lte-services-sc', $atts, $class, $id);
		echo '<div class="swiper-wrapper">';
	}
		else {

		echo '<div class="lte-lte-services-sc-wrapper lte-services-sc lte-layout-'.esc_attr($args['layout']).'"><div class="row">';

	}	

	set_query_var( 'vibratex_services_layout', $args['layout'] );
	set_query_var( 'vibratex_read_more', $args['read_more'] );

	$x = 0;


	if ( $args['layout'] == 'photos' ) {	

		while ( $query->have_posts() ) {

			$query->the_post();
			$x++;

			$subheader = fw_get_db_post_option(get_The_ID(), 'subheader');
			$cut = fw_get_db_post_option(get_The_ID(), 'cut');
			$image = fw_get_db_post_option(get_The_ID(), 'image');
			$header = get_the_title();
			$link = fw_get_db_post_option(get_The_ID(), 'link');

			if ( empty($link) ) {

				$link = get_the_permalink();
			}

			$item_class = array_merge($item_class, lte_responsive_cols($args));

			?>
			<div class="lte-item <?php echo esc_attr(implode(' ', $item_class)); ?>">
				<div class="lte-item-inner">
					<?php get_template_part( 'tmpl/content', 'services' ); ?>
				</div>
			</div>
			<?php
		}
	}
		else
	if ( $args['layout'] == 'tabs' ) {

		$content = [];
		$tabs = [];

		echo '<div class="container">';

			echo '<div class="lte-tabs-wrapper lte-tabs-large">';

				echo '<div class="lte-items">';

					while ( $query->have_posts() ) {

						$query->the_post();
						$x++;

			           	if ( $x == 1) $class = ' active'; else $class = '';

						$header = get_the_title();

						$image_alt = fw_get_db_post_option(get_The_ID(), 'image_alt');
						if ( empty($image_alt) AND empty($image_alt['url'])) {

							$image_alt = [];
							$image_alt['url'] = '';
						}

						$tabs[] = '<span class="lte-tab lte-tab-'.$x.$class.' lte-cursor-follow-wrapper" data-img-alt="'.esc_attr($image_alt['url']).'" data-lte-id="'.$x.'">'.esc_html($header);
							
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'vibratex-product-tiny' );

						if ( !empty($image) ) {

							$tabs[] = '<span class="lte-tab-cursor lte-tab-cursor-'.$x.'"><img src="'.$image[0].'" alt="."></span>';
						}

						$tabs[] = '</span>';



						$bg = '';
	/*
						if ( !empty($image) ) {

							$bg = ' style="background-image: url('.esc_url($image[0]).')"';
						}
	*/
			           	$contentElementor = \Elementor\Plugin::instance()->frontend->get_builder_content(get_the_ID(), false);

			           	$content[] = 
			           	'<div class="lte-item lte-item-'.$x.$class.'"'.$bg.'>'.

					       	'<div class="lte-item-content">'.
					       		'<div class="lte-item-content-inner">'.$contentElementor.'</div>'.
					       	'</div>'.

						'</div>';
					}

					echo implode($content);	

				echo '</div>';

				echo '<div class="lte-tabs-container lte-cursor-follow-parent">';

					echo implode($tabs);	

				echo '</div>';
			echo '</div>';
		echo '</div>';
	}

	if ( !empty($args['swiper']) OR $args['layout'] == 'slider' ) {

		echo '</div>';	
		echo '<div class="swiper-pagination"></div>';
	}
		

	echo '</div></div>';


	wp_reset_postdata();
}

