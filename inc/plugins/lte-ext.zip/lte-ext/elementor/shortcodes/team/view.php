<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Team Shortcode
 */

$query_args = array(
	'post_type' => 'team',
	'post_status' => 'publish',
	'posts_per_page' => (int)($args['limit']),
);

if ( !empty($args['ids']) ) {

	$query_args['post__in'] = explode(',', esc_attr($args['ids']));
}
	else
if ( !empty($args['cat']) ) {

	$query_args['tax_query'] = 	array(
			array(
	            'taxonomy'  => 'team-category',
	            'field'     => 'if', 
	            'terms'     => array(esc_attr($args['cat'])),
			)
    );
}

if ( !empty($args['orderby']) ) {

	$query_args['orderby'] = $args['orderby'];
}		

if ( !empty($args['orderway']) ) {

	$query_args['order'] = $args['orderway'];
}


$query = new WP_Query( $query_args );

if ( $query->have_posts() ) {

	$item_class = [];
	if ( $args['layout'] == 'swiper' ) {

		$args['swiper_breakpoint_xl'] = $args['columns_xl'];
		$args['swiper_breakpoint_lg'] = $args['columns_lg'];
		$args['swiper_breakpoint_md'] = $args['columns_md'];
		$args['swiper_breakpoint_sm'] = $args['columns_sm'];
		$args['swiper_breakpoint_ms'] = $args['columns_ms'];
		$args['swiper_breakpoint_xs'] = $args['columns_xs'];
		$args['swiper_arrows'] = 'sides-outside';
/*		$args['swiper_effect'] = 'coverflow';*/
		
		$args['swiper_slides_per_group'] = -1;

		$item_class[] = 'swiper-slide';
		echo lte_swiper_get_the_container('lte-team-list', $args);
		echo '<div class="swiper-wrapper">';
	}
		else {

		$item_class = array_merge($item_class, lte_responsive_cols($args));

		echo '<div class="lte-team-list-wrapper"><div class="lte-team-list"><div class="row">';
	}

	while ( $query->have_posts() ) {

		$query->the_post();

		if ( $args['layout'] == 'swiper' ) {

			echo '<div class="lte-item '.esc_attr(implode(' ', $item_class)).'">';
				get_template_part( 'tmpl/content', 'team' );
			echo '</div>';			
		}
			else {

			echo '<div class="lte-item '.esc_attr(implode(' ', $item_class)).'">';
				get_template_part( 'tmpl/content', 'team' );
			echo '</div>';			
		}
	}

	if ( !empty($args['layout'] == 'swiper') ) {

		echo '</div>';	
	}
		
	echo '</div></div></div>';

	wp_reset_postdata();
}

