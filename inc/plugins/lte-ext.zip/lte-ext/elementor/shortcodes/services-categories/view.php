<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Services Shortcode
 */

$query_args = array(
     'taxonomy'     => 'services-category',
     'orderby'      => 'menu_order',
     'show_count'   => 0,
     'pad_counts'   => 0,
     'hierarchical' => 1,
     'title_li'     => '',
     'hide_empty'   => 0
);

$cats = [];
$list = get_categories( $query_args );

if ( !empty($list) ) {

	foreach ($list as $cat) {

		$thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true ); 
	    if ( !empty($thumbnail_id) ) {

	    	$image = wp_get_attachment_image_src($thumbnail_id, 'vibratex-wc-cat');
	    }
	    	else {

	    	$image = null;
	    }

	    $cats[$cat->term_id]['href'] = get_term_link($cat->slug, 'services-category');
	    $cats[$cat->term_id]['name'] = $cat->name;
	    $cats[$cat->term_id]['description'] = $cat->description;
	    $cats[$cat->term_id]['image'] = $image;
	    $cats[$cat->term_id]['image_id'] = $thumbnail_id;
	}	

	echo '<div class="lte-services-categories">
		<div class="row row-center">';

	foreach ( $cats as $tid => $item ) {

		$icon = fw_get_db_term_option($tid, 'services-category', 'icon');
		$photo = fw_get_db_term_option($tid, 'services-category', 'photo');
		$popular = fw_get_db_term_option($tid, 'services-category', 'popular');
		$new = fw_get_db_term_option($tid, 'services-category', 'new');
		$subheader = fw_get_db_term_option($tid, 'services-category', 'subheader');

		if ( empty($subheader) ) $subheader = '7 programs';

		$class_label = '';
		if ( !empty($popular) OR !empty($new) ) {

			$class_label = ' hasLabel';

			if ( !empty($new)) { $class_label .= ' lte-new'; }
		}

		echo '<div class="col-lg-3 col-md-4 col-sm-6 col-ms-6 col-xs-12">';
			echo '<div class="lte-item-wrapper">';

				echo '<div class="lte-item-inner">';

					echo '<a class="lte-item lte-item-front'.esc_attr($class_label).'" href="'.esc_url($item['href']).'">';

						echo '<span class="lte-item-inner-wrapper">';
							if ( !empty($popular)) {

								echo '<span class="lte-label lte-popular">'.esc_html__( 'Popular', 'lte-ext' ).'</span>';
							}

							if ( !empty($new)) {

								echo '<span class="lte-label lte-new">'.esc_html__( 'New', 'lte-ext' ).'</span>';
							}

							echo '<span class="lte-icon '.esc_attr($icon['icon-class']).'"></span>';

							echo '<span class="lte-header">'.esc_html($item['name']).'</span>';

							echo '<span class="lte-info">'.esc_html($subheader).'</span>';
						echo '</span>';

					echo '</a>';

					if ( !empty($photo) ) {

						$image = wp_get_attachment_image_src( $photo['attachment_id'], 'vibratex-blog' );

						echo '<a class="lte-item lte-item-back" href="'.esc_url($item['href']).'" style="background-image: url('.esc_url($image[0]).')">';

							echo '<span class="lte-item-inner-wrapper">';
							
								echo '<span class="lte-item-inner-info">';

									echo '<span class="lte-header">'.esc_html($item['name']).'</span>';

									if ( !empty($item['description']) ) {

										echo '<span class="lte-description">'.$item['description'].'</span>';
									}

								echo '</span>';

							echo '</span>';

						echo '</a>';
					}

				echo '</div>';

			echo '</div>';
		echo '</div>';
	}

		echo '</div>
	</div>';
}



