<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_Services_Categories_Widget extends Widget_Base {

	public function get_name() {
		return 'lte-services-categories';
	}

	public function get_title() {
		return esc_html__( 'Services Categories', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-post-list';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		lte_sc_output('services-categories', $settings);
	}
}




