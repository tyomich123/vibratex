<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_Effects_Widget extends Widget_Base {

	public function get_name() {
		return 'lte-effects';
	}

	public function get_title() {
		return esc_html__( 'Effects', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-image-rollover';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Layout', 'lte-ext' ),
			]
		);


			$this->add_control(
				'type',
				[
					'label' => esc_html__( 'Type', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'background-text',
					'options' => [
						'background-text' 		=> esc_html__('Background Text Fill', 'lte-ext'),
					],
				]
			);		
/*
			$this->add_control(
				'opacity',
				[
					'label' => esc_html__( 'Opacity', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => '0',
					'options' => $opacity,
					'condition' => [
						'type' => ['atoms'],
					],							
				]
			);
*/

			$this->add_control(
				'text',
				[
					'label' => __( 'Text', 'lte-ext' ),
					'description' => esc_html__( 'You can use {{ style }} for additional styling.', 'lte-ext' ),
					'type' => Controls_Manager::TEXT,
				]
			);

			$this->add_control(
				'times',
				[
					'label' => __( 'Repeat Times X', 'lte-ext' ),
					'default'	=>	5,
					'type' => Controls_Manager::TEXT,
					'description' => esc_html__( 'Integer number', 'lte-ext' ),
				]
			);

			$this->add_control(
				'times_y',
				[
					'label' => __( 'Repeat Times Y', 'lte-ext' ),
					'default'	=>	10,
					'type' => Controls_Manager::TEXT,
					'description' => esc_html__( 'Integer number', 'lte-ext' ),
				]
			);

			$this->add_control(
				'color',
				[
					'label' => esc_html__( 'Header Color', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'white',
					'options' => [
						'black'		=> esc_html__('Black', 'lte-ext'),
						'main'		=> esc_html__('Main Color', 'lte-ext'),
						'second'	=> esc_html__('Second Color', 'lte-ext'),
						'white'		=> esc_html__('White', 'lte-ext'),
					],
				]
			);	

			$this->add_control(
				'size',
				[
					'label' => esc_html__( 'Size', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'md',
					'options' => [
						'sm'		=> esc_html__('Small', 'lte-ext'),
						'md'		=> esc_html__('Medium', 'lte-ext'),
						'lg'		=> esc_html__('Large', 'lte-ext'),
					],
				]
			);	

			$this->add_control(
				'opacity',
				[
					'label' => __( 'Opacity', 'lte-ext' ),
					'default'	=>	10,
					'type' => Controls_Manager::SELECT,
					'options' => [1 => 10,20,30,40,50,60,70,80,90,100]
				]
			);			

		$this->end_controls_section();
	}

	protected function render() {

		wp_enqueue_script( 'anime', lteGetPluginUrl('/elementor/shortcodes/effects/anime.min.js'), array(), null, true );
		wp_enqueue_script( 'slide-background', lteGetPluginUrl('/elementor/shortcodes/effects/jquery.slide_background.js'), array('jquery', 'anime') , null, true );

		$settings = $this->get_settings_for_display();
		lte_sc_output('effects', $settings);
	}
}




