<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Effects Shortcode
 */

if ( (int)($args['times']) < 2 ) $args['times'] = 1;
if ( (int)($args['times_y']) < 2 ) $args['times_y'] = 1;

if ( $args['type'] == 'background-text' AND !empty($args['text']) ) {

	$wrapper_class = [];
	$wrapper_class[] = 'lte-repeating-bg-div';
	$wrapper_class[] = 'lte-color-'.$args['color'];
	$wrapper_class[] = 'lte-opacity-'.$args['opacity'];
	$wrapper_class[] = 'lte-size-'.$args['size'];

	$id = 'lte-rpt-txt-'.mt_rand(10000, 20000);

	$out = [];

  	$out[] = '<div class="'.esc_attr(implode(' ', $wrapper_class)).'">';

  		for ( $y = 0; $y <= (int)($args['times_y']); $y++) {
	  		
	  		$out[] = '<div class="lte-row">';
			  	for ( $x = 0; $x <= (int)($args['times']); $x++) {

			    	$out[] = wp_kses_post(lte_string_parse($args['text']));
			    }
	    	$out[] = '</div>';

	    }
    $out[] = '</div>';

    echo implode($out);
}	

/*
echo'
  <svg class="lte-repeating-bg">
    <defs>
      <pattern id="Text" x="0" y="0" width="1000" height="200 patternUnits="userSpaceOnUse">
        <text x="10" y="60" class="lte-background-text-style">
          NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;;NEWSLETTER
        </text>
        <text x="-100" y="165" class="lte-background-text-style">
          NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;;NEWSLETTER
        </text>        
      </pattern>
    </defs>
  
    <rect fill="url(#Text)" width="100%" height="100%"/>
  </svg>';
*/  
/*
  echo '


    <svg class="lte-repeating-bg">
    <defs>
      <pattern id="Text" x="0" y="0" width="1000" height="200" patternUnits="userSpaceOnUse">
        <text x="10" y="60" class="lte-background-text-style">
          NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;;NEWSLETTER
        </text>
        <text x="-100" y="165" class="lte-background-text-style">
          NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;NEWSLETTER&nbsp;&nbsp;;NEWSLETTER
        </text>        
      </pattern>
    </defs>
  
    <rect fill="url(#Text)" width="100%" height="100%"/>
  </svg>
 ';
*/ 
