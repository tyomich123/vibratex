<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Audio Track
 */

$number_escaped = '';
if ( !empty($args['number']) ) {

	$number_escaped = '<span>'.esc_html($args['number']).'</span>';	
} 

$file = ($args['file']);

echo '<div class="lte-media-element">
	<div class="row">
		<div class="col-sm-6">
			<div class="meta">
				<h6 class="header">'.$number_escaped.esc_html($args['title']).'</h6>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="media-content">
				'. do_shortcode('[audio src="'.esc_url(strtok($file, '?')).'" autoplay="0"]').'
			</div>
		</div>
	</div>		
	
</div>';
