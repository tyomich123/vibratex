<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Popup Dot Shortcode
 */

$args;

if ( !empty($args['icons']) ) {

}
/*
echo '<span class="lte-popup-watermark">';
	\Elementor\Icons_Manager::render_icon( $args['icon'], [ 'aria-hidden' => 'true' ] );
echo '</span>';
*/
$class = [];
$class[] = 'lte-pop-wrapper-dot-'. $args['color'];
$class[] = 'lte-pop-wrapper-background-'. $args['background'];
$class[] = 'lte-pop-wrapper-dothover-'. $args['color-dot-hover'];

echo '
  <div class="lte-pop-wrapper '.esc_attr(implode(' ', $class)).'">
    <div class="lte-circle"></div>
	  <div class="lte-content">
		  <div class="lte-header">' . esc_html($args['header']) .'</div>
		  <p class="lte-pop">' . esc_html($args['descr']).'</p>
	  </div>';
echo '</div>';


