<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_Popup_Dot_Widget extends Widget_Base {

	public function get_name() {
		return 'lte-popup-dot';
	}

	public function get_title() {
		return esc_html__( 'Popup Dot', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-youtube';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Layout', 'lte-ext' ),
			]
		);

			$this->add_control(
				'header',
				[
					'label' => esc_html__( 'Header', 'lte-ext' ),
					'type' => Controls_Manager::TEXT,
					'label_block'	=>	true,
				]
			);
			
			$this->add_control(
				'descr',
				[
					'label' => esc_html__( 'Descr', 'lte-ext' ),
					'type' => Controls_Manager::TEXT,
					'label_block'	=>	true,
				]
			);

			$this->add_control(
				'color',
				[
					'label' => esc_html__( 'Dot Color', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'second',
					'options' => [
						'black'		=> esc_html__('Black', 'lte-ext'),
						'main'		=> esc_html__('Main Color', 'lte-ext'),
						'second'	=> esc_html__('Second Color', 'lte-ext'),
						'gray'		=> esc_html__('Gray Color', 'lte-ext'),
						'white'		=> esc_html__('White', 'lte-ext'),
					],
				]
			);
			
			$this->add_control(
				'color-dot-hover',
				[
					'label' => esc_html__( 'Dot Hover Color', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'second',
					'options' => [
						'black'		=> esc_html__('Black', 'lte-ext'),
						'main'		=> esc_html__('Main Color', 'lte-ext'),
						'second'	=> esc_html__('Second Color', 'lte-ext'),
						'gray'		=> esc_html__('Gray Color', 'lte-ext'),
						'white'		=> esc_html__('White', 'lte-ext'),
					],
				]
			);

			$this->add_control(
				'background',
				[
					'label' => esc_html__( 'Background Color', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'second',
					'options' => [
						'black'		=> esc_html__('Black', 'lte-ext'),
						'main'		=> esc_html__('Main Color', 'lte-ext'),
						'second'	=> esc_html__('Second Color', 'lte-ext'),
						'gray'		=> esc_html__('Gray Color', 'lte-ext'),						
						'white'		=> esc_html__('White', 'lte-ext'),
					],
				]
			);	
			
			$this->add_control(
				'icon',
				[
					'label' => esc_html__( 'Watermark Icon', 'lte-ext' ),
					'type' => Controls_Manager::ICONS,
					'label_block'	=>	true,
				]
			);
			
		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		lte_sc_output('popup-dot', $settings);
	}
}




