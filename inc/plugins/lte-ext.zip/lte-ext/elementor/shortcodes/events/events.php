<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class LTE_Events_Widget extends Widget_Base {

	public function get_name() {
		return 'lte-events';
	}

	public function get_title() {
		return esc_html__( 'Events', 'lte-ext' );
	}

	public function get_icon() {
		return 'eicon-post-list';
	}

	public function get_categories() {
		return [ 'lte-category' ];
	}

	protected function register_controls() {
/*
		$categories = get_categories( [ 'taxonomy' => 'events-category' ]);
		$cats = array();
		foreach ($categories as $item) {

			$cats[$item->term_id] = $item->name;
		}		
*/
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Layout', 'lte-ext' ),
			]
		);

			$this->add_control(
				'important_note',
				[
					'type' => \Elementor\Controls_Manager::RAW_HTML,
					'raw' => esc_html__( "The content of Events can be edited in Events menu of Dashboard and it is controlled by the external plugin the Events Calendar.", 'lte-ext'),
				]
			);		

			$this->add_control(
				'layout',
				[
					'label' => esc_html__( 'Layout', 'lte-ext' ),
					'type' => Controls_Manager::SELECT,
					'default' => 'photos',
					'options' => [

						'table'		=>	esc_html__( "Table", 'lte-ext'),
						'grid'		=>	esc_html__( "Grid", 'lte-ext'),
					],
				]
			);	

			$this->add_control(
				'limit',
				[
					'label' => esc_html__( 'Limit', 'lte-ext' ),
					'type' => Controls_Manager::TEXT,
					'default' => '3',
				]
			);

			$this->add_control(
				'btn_text',
				[
					'label' => esc_html__( 'Button Text', 'lte-ext' ),
					'type' => Controls_Manager::TEXT,
					'default' => esc_html__( "More Info", 'lte-ext'),
				]
			);			
/*
			$this->add_control(
				'divider',
				[
					'label' => esc_html__( 'Divider', 'lte-ext' ),
					'type' => Controls_Manager::SWITCHER,
				]
			);
*/
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		lte_sc_output('events', $settings);
	}
}




