<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Events Shortcode
 */

$query_args = array(
	'post_type' => 'tribe_events',
	'post_status' => 'publish',
	'orderby' =>'meta_value',
	'meta_key' => '_EventStartDate',
	'order' => 'DESC',	
	'posts_per_page' => (int)($args['limit']),
);

$query = new WP_Query( $query_args );

if ( $query->have_posts() ) {

	$cols = 1;
	$class = '';

	if ( !empty($args['divider']) ) {

		$class .= ' hasDivider';
	}

	echo '<div class="lte-events-sc'.$class.' lte-events-layout-'.esc_attr($args['layout']).'">';

	while ( $query->have_posts() ) {

		if ( !function_exists('tribe_get_venue') ) break;
		
		$query->the_post();
		$subheader = str_replace(array('{{', '}}'), array('<strong>', '</strong>'), fw_get_db_post_option(get_The_ID(), 'subheader'));
		$cut = str_replace(array('{{', '}}'), array('<strong>', '</strong>'), nl2br(get_the_excerpt()));


		$item_cats = wp_get_post_terms( get_the_ID(), 'tribe_events_cat' );
		$item_term = '';
		if ( $item_cats && !is_wp_error ( $item_cats ) ) {
			
			foreach ($item_cats as $cat) {

				$item_term = $cat->name;
			}
		}

		$venue = tribe_get_venue();
		$organizer = tribe_get_organizer();

		$date = array();
		if (function_exists('tribe_get_start_date')) {

			$date['d'] = tribe_get_start_date(get_The_ID(), false, 'd');
			$date['M'] = tribe_get_start_date(get_The_ID(), false, 'F');
			$date['Y'] = tribe_get_start_date(get_The_ID(), false, 'Y');
			$date['date'] = tribe_get_start_date(get_The_ID(), false, 'd M Y');

			$date['time'] = tribe_get_start_date(get_The_ID(), false, 'H:i');
		}

		$sold = fw_get_db_post_option(get_The_ID(), 'sold');

		echo '<div class="lte-item">';

			if ( $args['layout'] == 'table' ) {

				echo '<div class="lte-event-date">';
					echo '<span class="lte-event-d">'.esc_html($date['d']).'</span>';
					echo '<span class="lte-event-m">'.esc_html($date['M']).'<span class="lte-event-y">'.esc_html($date['Y']).'</span></span>';				
				echo '</div>';

				if ( has_post_thumbnail() ) {

					echo '<div class="lte-img">';
					
						echo '<a href="'.get_the_permalink().'">';
							
							the_post_thumbnail('vibratex-partners');

						echo '</a>';

					echo '</div>';
				}

				echo '<div class="lte-info">';
				
					echo '<h5 class="lte-header"><a href="'.get_the_permalink().'">'. get_the_title() .'</a></h5>';
/*
					if ( !empty($date['time']) ) {

						echo '<span class="lte-event-time">'.esc_html($date['time']).'</span>';
					}

					if ( !empty( $organizer ) ) {

						echo '<span class="lte-event-organizer">'.esc_html($organizer).'</span>';
					}

					if ( !empty( $venue) ) {

						echo '<span class="lte-event-venue">'.esc_html($venue).'</span>';
					}
*/
				echo '</div>';

					$cut = get_the_excerpt();

					echo '<div class="lte-excerpt">';

						if ( !empty($cut) ) {

							echo wp_kses_post($cut);
						}				

					echo '</div>';

					if ( !empty($args['btn_text']) ) {

						echo '<div class="lte-link">';
							echo lte_button_sc([
								'href'		=>	get_the_permalink(),
								'header'	=>	$args['btn_text'],
								'color'		=>	'main',
								'size'		=>	'lg',
							]);
						echo '</div>';
					}

			}
				else {

				echo '<a href="'.get_the_permalink().'" class="lte-href-overlay"></a>';

				echo '<div class="lte-item-inner">';

					echo '<div class="lte-event-pre">
						<div class="lte-event-date">';
							echo '<span class="lte-event-d">'.esc_html($date['d']).'</span>';
						echo '</div>';

					echo '<div class="lte-info">';
					
						echo '<h5 class="lte-header"><a href="'.get_the_permalink().'">'. get_the_title() .'</a></h5>';

						echo '<span class="lte-event-m">'.esc_html($date['M']).', </span><span class="lte-event-y">'.esc_html($date['Y']).'</span>';				

						if ( !empty( $venue) ) {

							echo '<span class="lte-event-venue">'.esc_html($venue).'</span>';
						}

					echo '</div>
					</div>';

					$cut = get_the_excerpt();
					if ( !empty($cut) ) {

						echo '<div class="lte-excerpt">';

							echo wp_kses_post($cut);

							if ( !empty($args['btn_text']) ) {

								echo '<div class="lte-link">';
									echo '<a href="'.get_the_permalink().'" class="lte-more-link">' . $args['btn_text'] . '</a>';
								echo '</div>';
							}

						echo '</div>';
					}

				echo '</div>';
			}

			
		echo '</div>';
	}

	echo '</div>';

	wp_reset_postdata();
}

