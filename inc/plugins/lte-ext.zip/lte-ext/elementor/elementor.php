<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Elementor Widgets Extension
 */

/**
 * Adding new widgets
 */
if ( !function_exists('lte_elementor_widgets_init') ) {

	
	function lte_elementor_widgets_init() {

		if ( function_exists('FW') ) {

			$shortcodes_array = array(

					'audio-track'			=>	true,
					'blog'					=>	true,
					'button'				=>	true,
					'countup'				=>	true,
					'cf7'					=>	true,
					'icons'					=>	true,			
					'effects'				=>	true,
					'events'				=>	true,
					'gallery'				=>	true,
					'googlemaps'			=>	true,
					'header'				=>	true,
					'history'				=>	true,
					'links'					=>	true,
					'navmenu'				=>	true,

					'partners'				=>	true,
					'parallax-slider'		=>	true,
					'price'					=>	true,
					
					'products'				=>	true,				

					'product-categories'	=>	true,				

					'popup-dot'				=>	true,				

					'services'				=>	true,
					'services-categories'	=>	true,

					'tariff'				=>	true,
					'team'					=>	true,

					'testimonials'			=>	true,
					'video'					=>	true,		
					'zoomslider'			=>	true,		
					
			);


			foreach ($shortcodes_array as $item => $enabled) {

				$include = lteGetLocalPath( '/elementor/shortcodes/' . $item . '/' . $item . '.php' );
				if ( $enabled AND file_exists( $include ) ) {

					include_once $include;

					$classname = 'LTE_'.ucwords(str_replace('-', '_', $item)).'_Widget';
					\Elementor\Plugin::instance()->widgets_manager->register( new $classname() );					
					
				}
			}
		}
	}
}
add_action( 'elementor/widgets/register', 'lte_elementor_widgets_init', 100 );


/**
 * Elementor Global Scripts Init
 */
if ( !function_exists('lte_elementor_scripts') ) {

	function lte_elementor_scripts() {

		wp_enqueue_script('jquery-paroller', lteGetPluginUrl('assets/js/jquery.paroller.js'), array('jquery'), '1.4.7' );
	}
}
add_action('wp_enqueue_scripts', 'lte_elementor_scripts', 20 );

//if ( is_admin() ) {

	add_action('elementor/preview/enqueue_scripts', function() {

		lte_wp_enqueue('style', 'lte-elementor', 'assets/css/lte-elementor.css');
	});
//}

/**
 * Adding new controls
 */
if ( !function_exists('lte_elementor_controls_init') ) {

	function lte_elementor_controls_init() {

		$shortcodes_array = array(

			'section'			=>	true,
			'image'			=>	true,
		);

		foreach ($shortcodes_array as $item => $enabled) {

			$include = lteGetLocalPath( '/elementor/controls/control-' . $item . '.php' );
			if ( $enabled AND file_exists( $include ) ) {

				include_once $include;
			}
		}
	}
}
add_action( 'elementor/controls/controls_registered', 'lte_elementor_controls_init', 100 );


function lte_register_elementor_locations( $elementor_theme_manager ) {

	$elementor_theme_manager->register_location( 'header' );
	$elementor_theme_manager->register_location( 'footer' );
}
add_action( 'elementor/theme/register_locations', 'lte_register_elementor_locations' );


/**
 * Adding custom categories
 */
function add_elementor_widget_categories( $elements_manager ) {

	$elements_manager = \Elementor\Plugin::instance()->elements_manager;

	$category_prefix = 'lte';

	$elements_manager->add_category(

		'lte-category',
		[
			'title' => esc_html__( 'Just Themes', 'lte-ext' ),
			'icon' => 'fa fa-plug',
		]
	);

    $reorder_cats = function() use( $category_prefix ) {

        uksort( $this->categories, function( $keyOne, $keyTwo ) use ( $category_prefix ){

            if ( substr($keyOne, 0, 3) == $category_prefix ) {

                return -1;
            }

            if ( substr($keyTwo, 0, 3) == $category_prefix ) {

                return 1;
            }

            return 0;
        });

    };
    $reorder_cats->call($elements_manager);	

}
add_action( 'elementor/elements/categories_registered', 'add_elementor_widget_categories' );


/**
 * Displays shortcode entry
 * Every shortcode carefully checks the output and generates the secure and escaped content
 */
if ( !function_exists( 'lte_sc_output' ) ) {

	function lte_sc_output( $sc, $args ) {	

		$path = lteGetLocalPath('/elementor/shortcodes/'.$sc.'/view.php');
		ob_start();
		if (file_exists($path)) {

			include $path;
		}
		$out_escaped = ob_get_contents();
		ob_end_clean();

		echo $out_escaped;
	}
}

require_once LTE_PLUGIN_DIR . 'elementor/fontello/fontello.php';

function lte_add_cpt_support() {
    
	$cpt_support = get_option( 'elementor_cpt_support' );
	
	if( ! $cpt_support ) {
	    $cpt_support = [ 'page', 'post' ];
	    update_option( 'elementor_cpt_support', $cpt_support );
	}	

	if ( !in_array( 'sliders', $cpt_support ) ) {
	    $cpt_support[] = 'sliders';
	    update_option( 'elementor_cpt_support', $cpt_support );
	}
	
	if ( !in_array( 'albums', $cpt_support ) ) {
	    $cpt_support[] = 'albums';
	    update_option( 'elementor_cpt_support', $cpt_support );
	}
	
	if ( !in_array( 'sections', $cpt_support ) ) {
	    $cpt_support[] = 'sections';
	    update_option( 'elementor_cpt_support', $cpt_support );
	}

	if ( !in_array( 'team', $cpt_support ) ) {
	    $cpt_support[] = 'team';
	    update_option( 'elementor_cpt_support', $cpt_support );
	}	
}
add_action( 'init', 'lte_add_cpt_support' );

/**
 * Clearing old elementor css cache files
 */
if ( !function_exists('lte_clear_elementor_cache') ) {
	
	function lte_clear_elementor_cache() {

		if ( class_exists("\\Elementor\\Plugin") ) {

			delete_post_meta_by_key( '_elementor_css' );
			delete_option( '_elementor_global_css' );
			delete_option( 'elementor-custom-breakpoints-files' );

			$dir = wp_get_upload_dir();
			$dir = $dir['basedir'];				
			$path = $dir . '/elementor/css/' . '*';

			if ( !empty(glob( $path )) ) {

				foreach ( glob( $path ) as $file_path ) {
					
					unlink( $file_path );
				}		
			}			
		}
		
	}
}

add_action('fw:ext:backups:tasks:before_process', 'lte_clear_elementor_cache');

if ( !function_exists('lte_sections_save_postdata') ) {

	function lte_sections_save_postdata( $post_id, $post, $update ) {

		if ( function_exists('lte_clear_elementor_cache') ) {

			lte_clear_elementor_cache();
		}
	}	
}
add_action( 'save_post_sections', 'lte_sections_save_postdata', 10, 3 );
add_action( 'save_post_sliders', 'lte_sections_save_postdata', 10, 3 );
add_action( 'save_post_services', 'lte_sections_save_postdata', 10, 3 );



$additional_animations = apply_filters( 'elementor/controls/animations/additional_animations', [] );

if ( !function_exists('lte_elementor_additional_animations') ) {

	function lte_elementor_additional_animations() {

		$animations = ['Zooming Additional' => [ 'lteZoomOut' => 'Zoom Out' ] ];

		return $animations;
	}

	add_action('elementor/controls/animations/additional_animations', 'lte_elementor_additional_animations');
}


/**
 * Swiper slider container generation
 */
if ( !function_exists( 'lte_swiper_get_the_container' ) ) {

	function lte_swiper_get_the_container($class = '', $atts = array(), $classDefault = '') {

		wp_enqueue_script('lte-frontend');

		$data = array();
		
		$defaults = array(

			'swiper_arrows' 				=> 'sides',
			'swiper_autoplay'				=> 0,
			'swiper_autoplay_interaction'	=> false,
			'swiper_loop'					=> false,
			'swiper_pagination'				=> false,
			'swiper_speed'					=> 1000,
			'swiper_effect'					=> 'slide',
			'swiper_slides_per_group'		=> null,
			'swiper_breakpoint_xl'		=> 1,
			'swiper_breakpoint_lg'		=> null,
			'swiper_breakpoint_md'		=> null,
			'swiper_breakpoint_sm'		=> null,
			'swiper_breakpoint_ms'		=> null,
			'swiper_breakpoint_xs'		=> null,
			'swiper_center_slide'		=> null,
			'space_between'		=> 30,
			'simulate_touch'		=> true,
		);

		foreach ( $defaults as $key => $val ) {

			if ( !isset($atts[$key]) OR ( empty($atts[$key]) AND $atts[$key] !== "0" ) ) {

				$atts[$key] = $val;
			}
		}

		$data[] = 'data-space-between="'.esc_attr($atts['space_between']).'"';
		$data[] = 'data-arrows="'.esc_attr($atts['swiper_arrows']).'"';
		$data[] = 'data-autoplay="'.esc_attr($atts['swiper_autoplay']).'"';
		$data[] = 'data-autoplay-interaction="'.esc_attr($atts['swiper_autoplay_interaction']).'"';
		$data[] = 'data-loop="'.esc_attr($atts['swiper_loop']).'"';
		$data[] = 'data-speed="'.esc_attr($atts['swiper_speed']).'"';
		$data[] = 'data-effect="'.esc_attr($atts['swiper_effect']).'"';
		$data[] = 'data-slides-per-group="'.esc_attr($atts['swiper_slides_per_group']).'"';

		if ( isset($atts['simulate_touch']) AND $atts['simulate_touch'] === 'false' ) {

			$data[] = 'data-simulate-touch="-1"';
		}

 		if ( !empty($atts['swiper-pagination-custom']) ) {

 			$atts['swiper_pagination'] = 'custom';
 			$data[] = ' data-pagination-custom=\''. filter_var( json_encode($atts['swiper-pagination-custom']), FILTER_SANITIZE_SPECIAL_CHARS ) .'\' ';
 		}

		if ( !empty($atts['swiper_pagination']) ) {

			$data[] = 'data-pagination="'.esc_attr($atts['swiper_pagination']).'"';
		}

		if ( !empty($atts['swiper_center_slide']) ) {

			$data[] = 'data-center-slide="'.esc_attr($atts['swiper_center_slide']).'"';
		}

		$data[] = 'data-breakpoints="'.esc_attr(implode(';', array($atts['swiper_breakpoint_xl'], $atts['swiper_breakpoint_lg'], $atts['swiper_breakpoint_md'], $atts['swiper_breakpoint_sm'], $atts['swiper_breakpoint_ms'], $atts['swiper_breakpoint_xs']))).'"';

		if ( !empty($atts['fc'])) $fc = ' lte-fc'; else $fc = '';

		echo '<div class="lte-swiper-slider-wrapper'.esc_attr($fc).'"><div class="lte-swiper-slider swiper-container '.esc_attr(implode(' ', array($class, $classDefault))).'" '.implode(' ', $data).'>';
	}
}


if ( !function_exists('lte_elementor_responsive_options') ) {

	function lte_elementor_responsive_options($options = null) {

		$controls = [];

		if ( empty($options) ) { 

			$options[1] = 1;
		}

		$swiper_items = [
			'xl'	=>	[ esc_html__( 'Extra Large Desktop, 1600px', 'vibratex' ), 4],
			'lg'	=>	[ esc_html__( 'Large Desktop, 1200px,', 'vibratex' ), 4],
			'md'	=>	[ esc_html__( 'Notebook, 1000px', 'vibratex' ), 4],
			'sm'	=>	[ esc_html__( 'Tablet, 768px', 'vibratex' ), 3],
			'ms'	=>	[ esc_html__( 'Horizontal Mobile, 480px', 'vibratex' ), 3],
			'xs'	=>	[ esc_html__( 'Mobile', 'vibratex' ), 1],
		];

		foreach ( $swiper_items as $bp => $item ) {

			$controls['columns_' . $bp] =
				[
					'label' => $item[0],
					'type' => 'Controls_Manager::SELECT',
					'label_block' => true,
					'default' => $item[1],
					'options' => $options,
				];
		}

		return $controls;
	}
}


if ( !function_exists('lte_responsive_cols') ) {

	function lte_responsive_cols($config = null) {

		$options = lte_elementor_responsive_options();
		$class = [];

		foreach ( $options as $key => $val ) {

			$opt = (int)(12 / $config[$key]);
			if ( $config[$key] == 5 ) $opt = 5;
			$class[] = 'col-'.str_replace('columns_', '', $key).'-'.$opt;
		}

		return $class;
	}
}


/**
 * Display section edit link in preview mode
 * in progress
 */
if ( !function_exists( 'lte_filter_section' ) ) {

	function lte_section_link( $content, $section_id ) {
		
		$out = '';
		
		if ( isset($_GET['elementor-preview']) AND $_GET['elementor-preview'] != $section_id ) {
/*
				$out .= '
				<div class="lte-section-link">
					<a target="_blank" href="'.esc_url( admin_url( sprintf( "post.php?post=%d&amp;action=elementor", $section_id ) ) ).'">'.
						sprintf( esc_html__('Open "%s" customization tab.', 'lte-ext'), esc_html( get_the_title($section_id) ) ).
					'</a>
				</div>';
*/				
		}

		return $content . $out;
	}

	add_filter( 'lte_filter_section', 'lte_section_link', 10, 3 );
}


